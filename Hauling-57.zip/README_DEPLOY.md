# Sistem Hauling V6 (Supabase + Vercel)

## Isi paket
- `supabase_schema.sql`  : skema database lengkap (tabel, trigger, FIFO, jurnal, laporan, RLS, storage, data awal). Jalankan sekali.
- `index.html`           : aplikasi web (satu berkas). Isi `SUPABASE_URL` dan `SUPABASE_ANON_KEY` di bagian atas script, atau isi lewat layar konfigurasi saat pertama dibuka.
- `sw.js`, `manifest.webmanifest`, `icon.svg`, `vercel.json` : PWA (bisa dipasang di HP, kerangka aplikasi tersedia offline).
- `uji/`                 : uji otomatis opsional (Playwright + Supabase tiruan) untuk memeriksa antarmuka tanpa server.

## Pemasangan
1. Supabase: buat proyek. SQL Editor > tempel seluruh `supabase_schema.sql` > Run. Authentication > Providers > Email aktif (matikan "Confirm email" bila ingin langsung masuk).
2. Isi `SUPABASE_URL` dan `SUPABASE_ANON_KEY` (Project Settings > API, kunci *anon public*; JANGAN pakai service_role) di `index.html`.
3. Vercel: unggah folder ini (atau hubungkan repo). Tanpa build; framework "Other".
4. Buka situs, Daftar akun pertama: otomatis Admin. Ikuti Setting > Panduan Data Awal.
5. Akun berikutnya mendaftar sendiri lalu diaktifkan Admin di Setting > Pengguna (pilih peran dan tautkan ke karyawan).

## Catatan keamanan
- Semua hak akses ditegakkan di database (Row Level Security dan pemeriksaan peran di setiap fungsi). Layar hanya menyembunyikan menu.
- Tabel transaksi tidak bisa ditulis langsung dari klien kecuali Admin pada master/konfigurasi; semua transaksi lewat fungsi database yang memvalidasi.
- View buku besar tidak bisa dibaca langsung klien; hanya lewat fungsi laporan yang memeriksa peran.
- Foto disimpan di bucket privat `lampiran`, folder per pengguna.
